# controlplane-dataplane
TalOS or K3s cluster setup for control-plane & data-plane on different cloud providers and on-premise
